package pblc.comparablepkg;

/* You need to implement Comparable otherwise 'sort'
   will not work, also you must implement method compareTo() */

public class Person implements Comparable<Person> {
	private String name;
	private int age;
	private String nationality;
	//constructor
	Person(String name, int age, String nationality) {
		super();
		this.name = name;
		this.age = age;
		this.nationality = nationality;
	}
	//getters
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public String getNationality() {
		return nationality;
	}
	//setters
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	@Override
	public String toString() {
		return "Person, name: " + name 
		+      ", age: " + age
		+      ", nationality: " + nationality; 
	}

	@Override 
	public int compareTo(Person p) {
		/* if
		 * this > p -> return +
		 * this < p -> return -
		 * this == p -> return 0
		 */

		if (this.getAge() < p.getAge()) 
			return -1;
		else
			return 1;
	}
}