package pblc.comparablepkg;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class ComparableClass {
	public static void main(String[] args) {
		List<Person> people = new ArrayList<>();
		people.add(new Person("Rob", 19, "South African"));
		people.add(new Person("Clint", 39, "Chinese"));
		people.add(new Person("Jill", 29, "American"));
		people.add(new Person("Peter", 12, "Russian"));

		System.out.println("Unsorted: ");
		for (Person p : people) {
			System.out.println(p);
		}

		Collections.sort(people);

		System.out.println("Sorted: ");
		for (Person p : people) {
			System.out.println(p);
		}
	}
}