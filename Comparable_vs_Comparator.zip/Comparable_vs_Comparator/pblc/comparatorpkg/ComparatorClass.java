package pblc.comparatorpkg;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;

/* When using comparator you can specify the sort logic as the second parameter to sort() */

public class ComparatorClass {
	public static void main(String[] args) {
		List<Person> people = new ArrayList<>();
		people.add(new Person("Rob", 19, "South African"));
		people.add(new Person("Clint", 39, "Chinese"));
		people.add(new Person("Jill", 29, "American"));
		people.add(new Person("Peter", 12, "Russian"));

		System.out.println("Unsorted: ");
		for (Person p : people) {
			System.out.println(p);
		}

		// anon inner class
		Comparator<Person> comparator = new Comparator<Person>() {
			public int compare(Person p1, Person p2) {
				if (p1.getAge() < p2.getAge())
					return -1;
				else
					return 1;
			}
		};

		Collections.sort(people, comparator);

		System.out.println("Sorted: ");
		for (Person p : people) {
			System.out.println(p);
		}
	}
}