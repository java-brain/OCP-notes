package pblc.dflt.unit1;

import java.util.Arrays;
import java.util.List;

import pblc.dflt.common.Person;

public class Unit1Exercise {
	public static void main(String[] args) {	
	 	List<Person> people = Arrays.asList(
			new Person("Sandy", "Corner", 25),
			new Person("Andy", "Listener", 35),
			new Person("Sunil", "Langa", 45),
			new Person("Cassanova", "Peterson", 55),
			new Person("Harry", "Cat", 49)
		);
	 	
	 	// Step 1: Sort list by last name
	 	
	 	// Step 2: Create a method that prints all elements in the list
	 	
	 	// Step 3: Create a method that prints all people that have last name beginning with C
	 	
	 	// Have the methods accept behavior instead of hard-coding them. For example, pass 
	 	// in behavior to find if a person's last name begins with 'C'.
	}
}
