package pblc.dflt.unit2;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

import pblc.dflt.common.Person;

public class StandardFunctionalInterfacesExample {

	public static void main(String[] args) {
		List<Person> people = Arrays.asList(
				new Person("Sandy", "Corner", 25),
				new Person("Candy", "Listener", 35),
				new Person("Sunil", "Langa", 45),
				new Person("Cassanova", "Peterson", 55),
				new Person("Harry", "Cat", 49),
				new Person("Ejioma", "Adam", 16),
				new Person("Larry", "Borman", 29),
				new Person("Whitney", "Edenvale", 87),
				new Person("Gary", "Diet", 41)
			);
		 	
		 	// Step 1: Sort list by last name
			Collections.sort(people, (o1,o2) -> o1.getLastName().compareTo(o2.getLastName()));
		 	
		 	// Step 2: Create a method that prints all elements in the list
			System.out.println("Printing all people:");
			printConditionally(people, p -> true);
		 	
		 	// Step 3: Create a method that prints all people that have last name beginning with C
			System.out.println("Printing all people with last name beginning with C:");
			printConditionally(people, p -> p.getLastName().startsWith("C"));
		 	
			System.out.println("Printing all people with first name beginning with C:");
			printConditionally(people, p -> p.getFirstName().startsWith("C"));
	}
	
	private static void printConditionally(List<Person> people, Predicate<Person> predicate) {
		for (Person p : people) {
			if (predicate.test(p)) {
				System.out.println(p);
			}
		}
	}
}



