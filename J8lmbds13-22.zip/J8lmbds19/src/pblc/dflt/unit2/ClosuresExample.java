package pblc.dflt.unit2;

public class ClosuresExample {

	public static void main(String[] args) {
		int a = 10;
		int b = 20; // effectively final
		
		doProcess(a, new Process() {

			@Override
			public void process(int i) {
				//b = 40; // if this is uncommented it will cause a compiler error
				System.out.println(i + b);
			}
			
		});
		
	}
	
	public static void doProcess(int i, Process p) {
		// variable 'b' is not in scope here, Java is keeping track of the effectively final variable
		p.process(i);
	}

}

interface Process {
	void process(int i);
}
