package pblc.dflt.unit2;

// Shows that lambdas are not syntactical sugar for anonymous inner classes, lambdas do not always behave the same 

public class ThisReferenceExample {
	public void doProcess(int i, Process p) {
		p.process(i);
	}
	public static void main(String[] args) {
		ThisReferenceExample thisReferenceExample = new ThisReferenceExample();
		// System.out.println(this); // Cannot use this in a static context
		// Using anonymous inner class
		thisReferenceExample.doProcess(10, new Process() {

			@Override
			public void process(int i) {
				System.out.println("Value of i is " + i);
				// Even though you are in a static method, you can access 'this',
				// because you are working within the instance of an object
				System.out.println(this);
			}
			
			public String toString() {
				return "This is the anonymous inner class";
			}
			
		});
	}
}
