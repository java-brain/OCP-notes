package pblc.dflt;

public class RunnableExample {
	public static void main(String[] args) {
		//Classic example of an anonymous inner class, a lambda would be suitable instead
		Thread myThread = new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("Printed inside Runnable");
			}
		});
		myThread.run();
		
	}
}
