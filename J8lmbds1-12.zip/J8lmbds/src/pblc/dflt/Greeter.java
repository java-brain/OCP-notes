package pblc.dflt;

public class Greeter {
	public void greet() {
		System.out.println("Hello world");
	}
	public static void main(String[] args) {
		Greeter greeter = new Greeter();
		greeter.greet();
	}
}
