package pblc.dflt;

public interface Greeting {
	public void perform();
}
