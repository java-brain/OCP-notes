package pblc.dflt;

public class RunnableExample {
	public static void main(String[] args) {
		Thread myThread = new Thread(() -> System.out.println("Printed by a lambda inside Runnable"));
		myThread.run();
	}
}
