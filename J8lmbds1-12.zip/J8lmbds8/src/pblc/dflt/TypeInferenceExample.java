package pblc.dflt;

public class TypeInferenceExample {
	public static void main(String[] args) {
		printLambda(s -> s.length());
	}
	
	public static void printLambda(StringLengthLambda l) {
		System.out.println(l.calcLength("hello string"));
	}
	
	interface StringLengthLambda {
		int calcLength(String s);
	}
}
