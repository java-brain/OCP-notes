package pblc.dflt;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Unit1Exercise {
	public static void main(String[] args) {	
	 	List<Person> people = Arrays.asList(
			new Person("Sandy", "Corner", 25),
			new Person("Andy", "Listener", 35),
			new Person("Sunil", "Langa", 45),
			new Person("Cassanova", "Peterson", 55),
			new Person("Harry", "Cat", 49)
		);
	 	
	 	// Step 1: Sort list by last name
	 	Collections.sort(people, new SortByLastName());
	 	
	 	// Step 2: Create a method that prints all elements in the list
	 	printList(people);
	 	
	 	// Step 3: Create a method that prints all people that have last name beginning with C
	 	System.out.println("<-------------------------->");
	 	printList(people, "C");
	 	
	 	// Have the methods accept behavior instead of hard-coding them. For example, pass 
	 	// in behavior to find if a person's last name begins with 'C'.
	}
	
	public static void printList(List<Person> l) {
		for (Person p: l) {
			System.out.println(p);
		}
	}
	
	public static void printList(List<Person> l, String s) {
		for (Person p: l) {
			if (p.getLastName().startsWith(s)) {
				System.out.println(p);
			}
		}
	}
	
}

class SortByLastName implements Comparator<Person> {
	@Override
	public int compare(Person o1, Person o2) {
		return o1.getLastName().compareTo(o2.getLastName());
	}	
}