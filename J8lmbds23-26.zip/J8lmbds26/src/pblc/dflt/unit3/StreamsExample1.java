package pblc.dflt.unit3;

import java.util.Arrays;
import java.util.List;

import pblc.dflt.common.Person;

public class StreamsExample1 {

	public static void main(String[] args) {
		List<Person> people = Arrays.asList(
				new Person("Sandy", "Corner", 25),
				new Person("Candy", "Listener", 35),
				new Person("Sunil", "Langa", 45),
				new Person("Cassanova", "Peterson", 55),
				new Person("Harry", "Cat", 49),
				new Person("Ejioma", "Adam", 16),
				new Person("Larry", "Borman", 29),
				new Person("Whitney", "Edenvale", 87),
				new Person("Gary", "Diet", 41)
		);
		
		/*people.stream()
		.filter(p -> p.getFirstName().contains("and"))
		.forEach(p -> System.out.println(p.getFirstName()));*/
		
		long count = people.stream()
		.filter(p -> p.getLastName().startsWith("and"))
		.count(); // Can't have more methods after count
		
		System.out.println(count);
		
		// You can have different portions of the collection handled by different cores
		long count2 = people.parallelStream()
				.filter(p -> p.getLastName().contains("and"))
				.count();
		
		System.out.println(count2);
		
		/* In summary: 
		 * Why Lambdas?
		 * Enables functional programming
		 * Readable and concise code
		 * Easier-to-use APIs and libraries
		 * Enables support for parallel processing */

	}

}
