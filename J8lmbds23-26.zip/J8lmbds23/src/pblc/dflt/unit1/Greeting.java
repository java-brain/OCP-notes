package pblc.dflt.unit1;

public interface Greeting {
	public void perform();
}
